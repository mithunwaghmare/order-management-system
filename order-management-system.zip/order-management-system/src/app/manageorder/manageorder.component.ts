﻿import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { AccountService } from '../_services';
import { CreateOrder } from '../_models';
import { User } from '../_models';
import { Router } from '@angular/router';


@Component({ selector: 'ngbd-pagination-basic',templateUrl: 'manageorder.component.html' })
export class ManageOrderComponent implements OnInit {
    user: User;
    isAdmin: boolean;
    orders: CreateOrder[] = [];
    page = 1;
    pageSize = 4;
    collectionSize = this.orders.length;
  

    constructor(private accountService: AccountService, private router: Router) {
        this.user = this.accountService.userValue;
        this.refreshCountries();
    }

    ngOnInit() {
        if(this.user.username == 'admin')
        {
            this.isAdmin = true;
            this.accountService.getAllOrders()
            .pipe(first())
            .subscribe(orders => this.orders = orders);
        }
        else
        {
            this.isAdmin = false;
            this.accountService.getAllOrders()
            .pipe(first())
            .subscribe(orders => this.orders = orders.filter(x => x.requester == this.user.username));
            
        }
    }

    deleteOrder(id: string) {
        const order = this.orders.find(x => x.id === id);
        order.isDeleting = true;
        this.accountService.deleteOrder(id)
            .pipe(first())
            .subscribe(() => this.orders = this.orders.filter(x => x.id !== id));
    }
    editOrder(id: string) {
        this.accountService.editOrder(id);
    }

    refreshCountries() {
        if(this.user.username == 'admin')
        {
            this.isAdmin = true;
            this.accountService.getAllOrders()
            .pipe(first())
            .subscribe(orders => this.orders = orders);

            this.orders = this.orders.map((country, i) => ({id: i + 1, ...country}))
            .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize)
        }
        else
        {
            this.isAdmin = false;
            this.accountService.getAllOrders()
            .pipe(first())
            .subscribe(orders => this.orders = orders.filter(x => x.requester == this.user.username));

            this.orders = this.orders.map((country, i) => ({id: i + 1, ...country}))
            .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize)
            
        }
        
        // this.orders = COUNTRIES
        //   .map((country, i) => ({id: i + 1, ...country}))
        //   .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
      }
}