export class CreateOrder {
    id: string;
    orderName: string;
    orderDesc: string;
    requester: string;
    orderDate: Date;
    orderStatus: string;
    contact: number;
    email: string;
    pickupDate: Date;
    deliveryDate: Date;
    goodsDesc: string;
    goodsWeight: number;
    sourceAddress: string;
    destinationAddress: string;
    modeOfTransport: string;
    isDeleting:boolean;
}