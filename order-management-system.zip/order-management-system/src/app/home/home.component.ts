﻿import { Component } from '@angular/core';

import { User } from '../_models';
import { AccountService } from '../_services';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    user: User;
    isAdmin: boolean;

    constructor(private accountService: AccountService) {
        this.user = this.accountService.userValue;
    }
    ngOnInit() {
        if(this.user.username == 'admin')
        {
            this.isAdmin = true;
        }
        else
        {
            this.isAdmin = false;
        }
    }
}