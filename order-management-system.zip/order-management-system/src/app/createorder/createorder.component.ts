﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { CreateOrder } from '../_models';

import { AccountService, AlertService } from '../_services';

@Component({ templateUrl: 'createorder.component.html' })
export class CreateOrderComponent implements OnInit {
    form: FormGroup;
    id: string;
    isAddMode: boolean;
    loading = false;
    submitted = false;
    users = null;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private accountService: AccountService,
        private alertService: AlertService
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        this.isAddMode = !this.id;
        this.accountService.getAll()
            .pipe(first())
            .subscribe(users => this.users = users);
        // password not required in edit mode
        const passwordValidators = [Validators.minLength(6)];
        if (this.isAddMode) {
            passwordValidators.push(Validators.required);
        }

        this.form = this.formBuilder.group({
            orderName: ['', Validators.required],
            orderDesc: ['', Validators.required],
            requester: ['', Validators.required],
            orderDate: ['', Validators.required],

            orderStatus: ['Created', Validators.required],
            contact: ['', Validators.required],
            email: ['', Validators.required],
            pickupDate: ['', Validators.required],

            deliveryDate: ['', Validators.required],
            goodsDesc: ['', Validators.required],
            goodsWeight: ['', Validators.required],
            sourceAddress: ['', Validators.required],

            destinationAddress: ['', Validators.required],
            modeOfTransport: ['', Validators.required],
        });

        if (!this.isAddMode) {
            this.accountService.getOrderById(this.id)
                .pipe(first())
                .subscribe(x => this.form.patchValue(x));
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form.invalid) {
            return;
        }

        this.loading = true;
        if (this.isAddMode) {
            this.createOrder();
        } else {
            this.updateOrder();
        }
    }

    private createOrder() {
        this.accountService.addOrder(this.form.value)
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('Order added successfully', { keepAfterRouteChange: true });
                    this.router.navigate(['../'], { relativeTo: this.route });
                },
                error: error => {
                    this.alertService.error(error);
                    this.loading = false;
                }
            });
    }

    private updateOrder() {
        this.accountService.updateOrder(this.id, this.form.value)
            .pipe(first())
            .subscribe({
                next: () => {
                    this.alertService.success('Update successful', { keepAfterRouteChange: true });
                    this.router.navigate(['../../'], { relativeTo: this.route });
                },
                error: error => {
                    this.alertService.error(error);
                    this.loading = false;
                }
            });
    }
}